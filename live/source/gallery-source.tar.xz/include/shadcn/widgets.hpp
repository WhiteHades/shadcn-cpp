// SPDX-License-Identifier: MIT
#pragma once

#include <shadcn/core.hpp>
#include <QCheckBox>
#include <QFrame>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QPointer>
#include <QProgressBar>
#include <QProxyStyle>
#include <QPushButton>
#include <QPointF>
#include <array>
#include <concepts>
#include <utility>
#include <vector>

class QApplication;
class QHBoxLayout;
class QVBoxLayout;
class QVariantAnimation;

namespace shadcn {

/// Owns the theme values. QApplication owns an installed Style.
class Style final : public QProxyStyle {
    Q_OBJECT
public:
    explicit Style(Theme theme = Theme::neutral(), MotionPolicy motion = MotionPolicy::Full);
    [[nodiscard]] const Theme& theme() const noexcept { return theme_; }
    [[nodiscard]] MotionPolicy motion() const noexcept { return motion_; }
    int pixelMetric(PixelMetric metric, const QStyleOption* option = nullptr,
                    const QWidget* widget = nullptr) const override;
    int styleHint(StyleHint hint, const QStyleOption* option = nullptr,
                  const QWidget* widget = nullptr, QStyleHintReturn* data = nullptr) const override;
private:
    Theme theme_;
    MotionPolicy motion_;
};

/// Install the theme and bundled Geist font on the application's GUI thread.
/// Passing zero or a negative fontPixels preserves the application's current font size.
void install(QApplication& app, Theme theme = Theme::neutral(),
             MotionPolicy motion = MotionPolicy::Full, int fontPixels = 14);

/// Construct a widget owned by its parent and return a borrowed reference.
/// Do not delete the reference or also place it in an owning smart pointer.
// moc does not need to parse this constrained free-function template.
#ifndef Q_MOC_RUN
template<class T, class... Args>
    requires std::derived_from<T, QWidget> && std::constructible_from<T, Args..., QWidget*>
T& make_child(QWidget& parent, Args&&... args) {
    return *new T(std::forward<Args>(args)..., &parent);
}
#endif

/// Native button activation with upstream variants, sizes and hover transitions.
class Button : public QPushButton {
    Q_OBJECT
    Q_PROPERTY(bool invalid READ isInvalid WRITE setInvalid)
    Q_PROPERTY(bool rippleEnabled READ rippleEnabled WRITE setRippleEnabled)
public:
    explicit Button(const QString& text = {}, QWidget* parent = nullptr);
    [[nodiscard]] Variant variant() const noexcept { return variant_; }
    void setVariant(Variant variant);
    [[nodiscard]] ButtonSize buttonSize() const noexcept { return size_; }
    void setButtonSize(ButtonSize size);
    [[nodiscard]] bool isInvalid() const noexcept { return invalid_; }
    void setInvalid(bool invalid);
    /// Optional pointer ripple adapted from UI Components. Disabled by default.
    [[nodiscard]] bool rippleEnabled() const noexcept { return rippleEnabled_; }
    void setRippleEnabled(bool enabled);
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
protected:
    void paintEvent(QPaintEvent*) override;
    bool event(QEvent*) override;
    void keyPressEvent(QKeyEvent*) override;
    void mousePressEvent(QMouseEvent*) override;
    void changeEvent(QEvent*) override;
private:
    void updateHover();
    void clearRipples();
    /// Measures the visible label once and reuses it until the text, font or size changes.
    int labelWidth() const;
    struct Ripple { QPointF center; double diameter; QVariantAnimation* animation; };
    std::vector<Ripple> ripples_;
    mutable int labelWidth_ = -1;
    mutable QString labelText_;
    mutable QFont labelFont_;
    mutable ButtonSize labelSize_ = ButtonSize::Default;
    bool rippleEnabled_ = false;
    Variant variant_ = Variant::Default;
    ButtonSize size_ = ButtonSize::Default;
    bool invalid_ = false;
    double hoverAmount_ = 0;
    QVariantAnimation* hover_;
};

/// QLineEdit retains native selection, clipboard, undo, password and input method support.
/// File, date and number HTML input types need separate native components.
class Input : public QLineEdit {
    Q_OBJECT
    Q_PROPERTY(bool invalid READ isInvalid WRITE setInvalid)
public:
    explicit Input(QWidget* parent = nullptr);
    [[nodiscard]] bool isInvalid() const noexcept { return invalid_; }
    void setInvalid(bool invalid);
    /// Sets the error description exposed through Qt accessibility.
    void setError(const QString& message);
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
protected:
    void paintEvent(QPaintEvent*) override;
    void changeEvent(QEvent*) override;
    bool eventFilter(QObject* object, QEvent* event) override;
private:
    void updatePalette();
    /// Keeps a name on the field even when the application supplied only a placeholder.
    void refreshAccessibleName();
    bool invalid_ = false;
};

/// A static text badge.
class Badge : public QLabel {
    Q_OBJECT
public:
    explicit Badge(const QString& text = {}, QWidget* parent = nullptr);
    void setVariant(Variant variant);
    [[nodiscard]] Variant variant() const noexcept { return variant_; }
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
protected:
    void paintEvent(QPaintEvent*) override;
private:
    Variant variant_ = Variant::Default;
};

/// Label that focuses its Qt buddy or toggles a button when clicked.
class Label : public QLabel {
    Q_OBJECT
public:
    explicit Label(const QString& text = {}, QWidget* parent = nullptr);
    void setBuddy(QWidget* buddy);
protected:
    void mousePressEvent(QMouseEvent*) override;
    void mouseReleaseEvent(QMouseEvent*) override;
    bool eventFilter(QObject*, QEvent*) override;
private:
    QPointer<QWidget> buddy_;
    bool pressed_ = false;
};

/// Native checkbox semantics. The indeterminate state uses a dash.
class Checkbox : public QCheckBox {
    Q_OBJECT
    Q_PROPERTY(bool invalid READ isInvalid WRITE setInvalid)
public:
    explicit Checkbox(const QString& text = {}, QWidget* parent = nullptr);
    void setInvalid(bool invalid);
    [[nodiscard]] bool isInvalid() const noexcept { return invalid_; }
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
protected:
    void paintEvent(QPaintEvent*) override;
    bool hitButton(const QPoint& position) const override;
private:
    bool invalid_ = false;
};

enum class SwitchSize { Default, Sm };
/// Toggle switch. Set an accessible name or attach a Label before showing it.
class Switch : public QCheckBox {
    Q_OBJECT
public:
    explicit Switch(QWidget* parent = nullptr);
    void setSwitchSize(SwitchSize size);
    [[nodiscard]] SwitchSize switchSize() const noexcept { return size_; }
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
protected:
    void paintEvent(QPaintEvent*) override;
    void keyPressEvent(QKeyEvent*) override;
    bool hitButton(const QPoint& position) const override;
    bool event(QEvent*) override;
private:
    void updatePosition();
    SwitchSize size_ = SwitchSize::Default;
    double position_ = 0;
    QVariantAnimation* transition_;
};

/// A decorative line one logical pixel thick.
class Separator : public QFrame {
    Q_OBJECT
public:
    explicit Separator(Qt::Orientation orientation = Qt::Horizontal, QWidget* parent = nullptr);
    void setOrientation(Qt::Orientation orientation);
    [[nodiscard]] Qt::Orientation orientation() const noexcept { return orientation_; }
    QSize sizeHint() const override;
protected:
    void paintEvent(QPaintEvent*) override;
private:
    Qt::Orientation orientation_;
};

/// Native progress state with a rounded track and animated determinate updates.
/// setRange(0, 0) exposes an indeterminate state and draws an empty track, as upstream does.
class Progress : public QProgressBar {
    Q_OBJECT
public:
    explicit Progress(QWidget* parent = nullptr);
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
public slots:
    void setRange(int minimum, int maximum);
    void setMinimum(int minimum);
    void setMaximum(int maximum);
protected:
    void paintEvent(QPaintEvent*) override;
    bool event(QEvent*) override;
private:
    void updateFraction();
    double fraction_ = 0;
    double target_ = 0;
    QVariantAnimation* transition_;
};

/// Pulse animation runs only while this widget is visible and motion is enabled.
class Skeleton : public QWidget {
    Q_OBJECT
public:
    explicit Skeleton(QWidget* parent = nullptr);
    QSize sizeHint() const override;
protected:
    void paintEvent(QPaintEvent*) override;
    bool event(QEvent*) override;
private:
    void updateAnimation();
    double opacity_ = 1;
    QVariantAnimation* pulse_;
};

/// Card composition with owned header, content, footer and action layouts.
///
/// The stock card is one box. The root owns the vertical padding and the gaps, and the
/// header, content and footer are slots that only add horizontal padding. They are layouts
/// on the card itself rather than nested widgets, so there is nothing between the card and a
/// control that could clip it when the control shifts under the pointer.
class Card : public QFrame {
    Q_OBJECT
public:
    explicit Card(QWidget* parent = nullptr);
    ~Card() override;
    void setTitle(const QString& title);
    void setDescription(const QString& description);
    /// Draws a rule above the footer row and gives it the padding that rule implies. The
    /// stock footer only does this when the caller adds a border to it, so it is off by
    /// default and the card carries one fill from top to bottom.
    void setFooterBorder(bool enabled);
    /// Returned layouts are borrowed and remain owned by the card. Each joins the card's
    /// layout the first time it is requested and leaves no gap while it is empty.
    [[nodiscard]] QVBoxLayout& content();
    [[nodiscard]] QHBoxLayout& footer();
    [[nodiscard]] QVBoxLayout& action();
protected:
    void paintEvent(QPaintEvent*) override;
    void changeEvent(QEvent*) override;
private:
    /// Slot order, which is the order they appear in the card.
    enum Slot { Header, Content, Footer, SlotCount };
    void attach(Slot slot);
    [[nodiscard]] QLayout* layoutFor(Slot slot) const;
    [[nodiscard]] bool attached(Slot slot) const;
    void updateHeader();
    void updatePalette();
    QVBoxLayout* outer_;
    QGridLayout* header_;
    QLabel* title_;
    QLabel* description_;
    QVBoxLayout* content_;
    QHBoxLayout* footer_;
    QVBoxLayout* action_;
    bool footerBorder_ = false;
    bool actionAttached_ = false;
    std::array<bool, static_cast<std::size_t>(SlotCount)> attached_{};
};

} // namespace shadcn
